package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity {

    private Button button;
    private EditText editEmail, editPass;
    private TextView register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        register = findViewById(R.id.register);
        editEmail = findViewById(R.id.editTextEmail);
        editPass = findViewById(R.id.editTextPass);
        button = findViewById(R.id.button);


        register.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegister();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateLogin()) {
                    openHome();
                }
            }
        });
    }

    public void openRegister() {
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }

    //TODO: PASSWORD HASHING, EMAILS AND PASSWORDS TO BE COMPARED TO DATABASE OF ACCOUNTS
    public boolean validateLogin() {
        boolean valid = true;
        String email = editEmail.getText().toString();
        String pass = editPass.getText().toString();
        return valid;
    }

    public void openHome() {
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
}
