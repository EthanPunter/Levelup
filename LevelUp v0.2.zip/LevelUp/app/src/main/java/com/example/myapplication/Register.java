package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Register extends AppCompatActivity {

    private EditText editEmail, editPass, editCEmail, editCPass, name;
    private Button regButton;
    private ImageView emailError, passError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editEmail = findViewById(R.id.editTextEmail);
        editCEmail = findViewById(R.id.editTextCEmail);
        editPass = findViewById(R.id.editTextPass);
        editCPass = findViewById(R.id.editTextCPass);
        name = findViewById(R.id.editTextName);
        regButton = findViewById(R.id.regScreenButton);
        emailError = findViewById(R.id.emailError);
        passError = findViewById(R.id.passError);

        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateLogin()) {
                    openSurvey();
                }
            }
        });
    }

    public boolean validateLogin() {
        boolean eValid = false;
        boolean pValid = false;
        if (editEmail.getText().toString().equals(editCEmail.getText().toString())) {
            eValid = true;
            emailError.setVisibility(View.INVISIBLE);
        }
        if (editPass.getText().toString().equals(editCPass.getText().toString())) {
            pValid = true;
            passError.setVisibility(View.INVISIBLE);
        }
        if (eValid && pValid) {
            return true;
        }
        else {
            if (!eValid) {
                emailError.setVisibility(View.VISIBLE);
            }
            if (!pValid) {
                passError.setVisibility(View.VISIBLE);
            }
            return false;
        }
    }

    public void openSurvey() {
        User currentUser = new User();
        Intent intent = new Intent(this, Survey.class);
        currentUser.setName(name.getText().toString());
        currentUser.setEmail(editEmail.getText().toString());
        currentUser.setPassHash(editPass.getText().toString());
        intent.putExtra("user", currentUser);
        startActivity(intent);
    }
}
